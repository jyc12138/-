// Auto-generated. Do not edit!

// (in-package control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class fare_well {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.NowTask = null;
      this.NextTask = null;
      this.FinishState = null;
      this.NeedHelp = null;
    }
    else {
      if (initObj.hasOwnProperty('NowTask')) {
        this.NowTask = initObj.NowTask
      }
      else {
        this.NowTask = 0;
      }
      if (initObj.hasOwnProperty('NextTask')) {
        this.NextTask = initObj.NextTask
      }
      else {
        this.NextTask = 0;
      }
      if (initObj.hasOwnProperty('FinishState')) {
        this.FinishState = initObj.FinishState
      }
      else {
        this.FinishState = false;
      }
      if (initObj.hasOwnProperty('NeedHelp')) {
        this.NeedHelp = initObj.NeedHelp
      }
      else {
        this.NeedHelp = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type fare_well
    // Serialize message field [NowTask]
    bufferOffset = _serializer.uint8(obj.NowTask, buffer, bufferOffset);
    // Serialize message field [NextTask]
    bufferOffset = _serializer.uint8(obj.NextTask, buffer, bufferOffset);
    // Serialize message field [FinishState]
    bufferOffset = _serializer.bool(obj.FinishState, buffer, bufferOffset);
    // Serialize message field [NeedHelp]
    bufferOffset = _serializer.bool(obj.NeedHelp, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type fare_well
    let len;
    let data = new fare_well(null);
    // Deserialize message field [NowTask]
    data.NowTask = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [NextTask]
    data.NextTask = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [FinishState]
    data.FinishState = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [NeedHelp]
    data.NeedHelp = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'control/fare_well';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '84f13051f217fa80f46e12117d64e5e9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 Enter_Site = 1
    uint8 Recog_People_In_Need = 2
    uint8 Goto_Guest = 3
    uint8 Ask_Leaving = 4
    uint8 Recog_Guest_Info = 5
    uint8 Goto_Coatrack = 6
    uint8 Grasp_Coat = 7
    uint8 Return_to_Guest = 8
    uint8 Deliver_Coat = 9
    uint8 Goto_Exit = 10
    uint8 Goto_Cab = 11
    uint8 Talk_to_Cab_Drive = 12
    uint8 Return_Site = 13
    
    
    uint8 Help_Grasp = 14
    uint8 Help_Follow_Guest = 15
    
    uint8 NowTask
    uint8 NextTask
    bool FinishState
    bool NeedHelp
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new fare_well(null);
    if (msg.NowTask !== undefined) {
      resolved.NowTask = msg.NowTask;
    }
    else {
      resolved.NowTask = 0
    }

    if (msg.NextTask !== undefined) {
      resolved.NextTask = msg.NextTask;
    }
    else {
      resolved.NextTask = 0
    }

    if (msg.FinishState !== undefined) {
      resolved.FinishState = msg.FinishState;
    }
    else {
      resolved.FinishState = false
    }

    if (msg.NeedHelp !== undefined) {
      resolved.NeedHelp = msg.NeedHelp;
    }
    else {
      resolved.NeedHelp = false
    }

    return resolved;
    }
};

// Constants for message
fare_well.Constants = {
  ENTER_SITE: 1,
  RECOG_PEOPLE_IN_NEED: 2,
  GOTO_GUEST: 3,
  ASK_LEAVING: 4,
  RECOG_GUEST_INFO: 5,
  GOTO_COATRACK: 6,
  GRASP_COAT: 7,
  RETURN_TO_GUEST: 8,
  DELIVER_COAT: 9,
  GOTO_EXIT: 10,
  GOTO_CAB: 11,
  TALK_TO_CAB_DRIVE: 12,
  RETURN_SITE: 13,
  HELP_GRASP: 14,
  HELP_FOLLOW_GUEST: 15,
}

module.exports = fare_well;
