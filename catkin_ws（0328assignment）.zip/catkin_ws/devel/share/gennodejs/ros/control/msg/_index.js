
"use strict";

let fare_well = require('./fare_well.js');

module.exports = {
  fare_well: fare_well,
};
