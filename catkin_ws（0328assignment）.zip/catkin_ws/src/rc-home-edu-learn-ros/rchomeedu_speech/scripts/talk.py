#!/usr/bin/env python

import rospy, os, sys
from std_msgs.msg import String
from sound_play.libsoundplay import SoundClient

class TalkBack:
    def __init__(self, script_path):
        rospy.init_node('talk')
        rospy.on_shutdown(self.cleanup)
        self.soundhandle = SoundClient()
        
        # Wait a moment to let the client connect to the sound_play server
        rospy.sleep(1)
        
        # Make sure any lingering sound_play processes are stopped.
        self.soundhandle.stopAll()
        
        # Announce that we are ready for input
        rospy.loginfo("Say one of the navigation commands...")
	self.soundhandle.say('Hello')
	#rospy.sleep(5)

        # Subscribe to the recognizer output and set the callback function
        rospy.Subscriber('/lm_data', String, self.talkback)


    def talkback(self, msg):
        # Print the recognized words on the screen
        rospy.loginfo(msg.data)

	if msg.data.find('WHO ARE YOU')>-1:
                rospy.sleep(1)
                self.soundhandle.say(' My name is Trump Nice to meet you')
                rospy.loginfo('My name is Trump. Nice to meet you.')
	elif msg.data.find('HOW OLD ARE YOU')>-1:
                rospy.sleep(1)
                self.soundhandle.say('I am seventy four years old')
		rospy.loginfo('I am seventy four years old.')
	elif msg.data.find('HOW ARE YOU')>-1:
		self.soundhandle.say('I feel bad I may get corona virus')
                rospy.sleep(1)
                rospy.loginfo('I feel bad.I may get corona virus.')
	elif msg.data.find('WHAT FOOD DO YOU LIKE')>-1:
                rospy.sleep(1)
                self.soundhandle.say('I like coke and burger')
                rospy.loginfo('I like coke and burger.')
        elif msg.data.find('DO YOU LIKE MOVIE')>-1:
                rospy.sleep(1)
                self.soundhandle.say('Yes i do Especially home alone')
                rospy.loginfo('That is great.')
        elif msg.data.find('I LIKE IT TOO')>-1:
                rospy.sleep(1)
                self.soundhandle.say('That is great')
                rospy.loginfo('I like coke and burger.')
        elif msg.data.find('THANK YOU BYE')>-1:
                rospy.sleep(1)
                self.soundhandle.say('Bye Remember vote for me')
                rospy.loginfo('Bye.Remember vote for me.')
	else:rospy.sleep(3)

    def cleanup(self):
        self.soundhandle.stopAll()
        rospy.loginfo("Shutting down talkback node...")


if __name__=="__main__":
    try:
        TalkBack(sys.path[0])
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Talk node terminated.")
